import uuid
from datetime import datetime

def book_ticket(name, age, gender, source, destination):
    """
    Create a new ticket with the provided information
    
    Args:
        name (str): Passenger name
        age (int): Passenger age
        gender (str): Passenger gender
        source (str): Source station
        destination (str): Destination station
        
    Returns:
        dict: Newly created ticket
    """
    # Generate a unique ticket ID
    ticket_id = str(uuid.uuid4())[:8].upper()
    
    # Create ticket object
    ticket = {
        "id": ticket_id,
        "name": name,
        "age": age,
        "gender": gender,
        "source": source,
        "destination": destination,
        "booking_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return ticket

def modify_ticket(ticket_id, name, age, gender, source, destination, tickets):
    """
    Modify an existing ticket
    
    Args:
        ticket_id (str): ID of the ticket to modify
        name (str): Updated passenger name
        age (int): Updated passenger age
        gender (str): Updated passenger gender
        source (str): Updated source station
        destination (str): Updated destination station
        tickets (list): List of all tickets
        
    Returns:
        dict: Updated ticket or None if not found
    """
    for i, ticket in enumerate(tickets):
        if ticket["id"] == ticket_id:
            # Update ticket with new information
            updated_ticket = {
                "id": ticket_id,
                "name": name,
                "age": age,
                "gender": gender,
                "source": source,
                "destination": destination,
                "booking_time": ticket["booking_time"]  # Keep original booking time
            }
            
            # Replace the old ticket with the updated one
            tickets[i] = updated_ticket
            return updated_ticket
    
    return None

def cancel_ticket(ticket_id, tickets):
    """
    Cancel (remove) a ticket
    
    Args:
        ticket_id (str): ID of the ticket to cancel
        tickets (list): List of all tickets
        
    Returns:
        bool: True if ticket was canceled, False otherwise
    """
    for i, ticket in enumerate(tickets):
        if ticket["id"] == ticket_id:
            # Remove the ticket from the list
            tickets.pop(i)
            return True
    
    return False

def get_all_tickets(tickets):
    """
    Get all tickets
    
    Args:
        tickets (list): List of all tickets
        
    Returns:
        list: All tickets
    """
    return tickets

def get_ticket_by_id(ticket_id, tickets):
    """
    Get a specific ticket by ID
    
    Args:
        ticket_id (str): Ticket ID to find
        tickets (list): List of all tickets
        
    Returns:
        dict: Ticket object or None if not found
    """
    for ticket in tickets:
        if ticket["id"] == ticket_id:
            return ticket
    
    return None
