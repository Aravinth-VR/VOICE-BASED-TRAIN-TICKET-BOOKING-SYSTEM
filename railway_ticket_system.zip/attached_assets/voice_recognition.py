import streamlit as st
import speech_recognition as sr
import re
import time

def listen_for_command():
    """
    Listen for voice command and convert to text
    
    Returns:
        str: Recognized voice command text
    """
    # Initialize recognizer
    r = sr.Recognizer()
    
    try:
        with sr.Microphone() as source:
            # Create a placeholder to show that the system is listening
            placeholder = st.empty()
            placeholder.info("Listening... Speak now.")
            
            # Adjust for ambient noise and listen
            r.adjust_for_ambient_noise(source, duration=0.5)
            audio = r.listen(source, timeout=5, phrase_time_limit=5)
            
            placeholder.empty()
            placeholder.info("Processing your command...")
            
            # Recognize speech using Google Speech Recognition
            command = r.recognize_google(audio)
            return command
            
    except sr.WaitTimeoutError:
        placeholder.error("No speech detected. Please try again.")
    except sr.UnknownValueError:
        placeholder.error("Could not understand audio. Please try again.")
    except sr.RequestError as e:
        placeholder.error(f"Could not request results; {e}")
    except Exception as e:
        placeholder.error(f"Error: {str(e)}")
    
    return None

def extract_ticket_details(command):
    """
    Extract ticket booking details from voice command
    
    Args:
        command (str): Voice command text
        
    Returns:
        dict: Extracted ticket details
    """
    details = {}
    
    # Extract name
    name_match = re.search(r"for\s+([a-zA-Z\s]+?)(?:,|\s+age|\s+from|\s+to|$)", command, re.IGNORECASE)
    if name_match:
        details["name"] = name_match.group(1).strip()
    
    # Extract age
    age_match = re.search(r"age\s+(\d+)", command, re.IGNORECASE)
    if age_match:
        try:
            details["age"] = int(age_match.group(1))
        except ValueError:
            pass
    
    # Extract source station
    source_match = re.search(r"from\s+([a-zA-Z\s]+?)(?:\s+to|$)", command, re.IGNORECASE)
    if source_match:
        details["source"] = source_match.group(1).strip()
    
    # Extract destination station
    dest_match = re.search(r"to\s+([a-zA-Z\s]+?)(?:,|\s+with|\s+and|$)", command, re.IGNORECASE)
    if dest_match:
        details["destination"] = dest_match.group(1).strip()
    
    return details
