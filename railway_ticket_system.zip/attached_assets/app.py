import streamlit as st
import pandas as pd
import numpy as np
import uuid
from datetime import datetime
import time
import re

from voice_recognition import listen_for_command, extract_ticket_details
from ticket_operations import (
    book_ticket, 
    modify_ticket, 
    cancel_ticket, 
    get_all_tickets, 
    get_ticket_by_id
)
from stations import get_station_list

# Initialize session state variables if they don't exist
if 'tickets' not in st.session_state:
    st.session_state.tickets = []  # Store ticket data
if 'current_operation' not in st.session_state:
    st.session_state.current_operation = None
if 'listening' not in st.session_state:
    st.session_state.listening = False
if 'voice_message' not in st.session_state:
    st.session_state.voice_message = ""
if 'voice_command' not in st.session_state:
    st.session_state.voice_command = None
if 'ticket_details' not in st.session_state:
    st.session_state.ticket_details = {}
if 'selected_ticket_id' not in st.session_state:
    st.session_state.selected_ticket_id = None
if 'booking_step' not in st.session_state:
    st.session_state.booking_step = None
if 'user_voice_input' not in st.session_state:
    st.session_state.user_voice_input = None

# Page configuration
st.set_page_config(
    page_title="Railway Ticket Reservation System",
    page_icon="🚆",
    layout="wide"
)

# Main title
st.title("Railway Ticket Reservation System")
st.subheader("Voice-Activated Ticket Booking")

# Central Voice Command Button (made larger and more prominent)
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if st.button("🎤 SPEAK A COMMAND", key="main_voice_button", use_container_width=True):
        st.session_state.listening = True
        placeholder = st.empty()
        placeholder.info("Listening... Say a command.")
        
        # Listen for command
        command = listen_for_command()
        
        if command:
            placeholder.success(f"Recognized command: {command}")
            st.session_state.voice_command = command
            time.sleep(1)  # Brief pause to show the command
            
            # Set operation based on voice command
            if "book" in command.lower() or "new" in command.lower():
                st.session_state.current_operation = "book"
                # Extract initial details if available
                details = extract_ticket_details(command)
                if details:
                    st.session_state.ticket_details = details
                    if 'name' in details and 'age' in details and 'source' in details and 'destination' in details:
                        # If we have all details, prepare to confirm
                        st.session_state.booking_step = "confirm"
                    else:
                        # Start collecting missing details
                        st.session_state.booking_step = "collect_details"
                else:
                    st.session_state.booking_step = "collect_details"
            elif "modify" in command.lower() or "edit" in command.lower() or "change" in command.lower() or "update" in command.lower():
                st.session_state.current_operation = "modify"
            elif "cancel" in command.lower() or "delete" in command.lower() or "remove" in command.lower():
                st.session_state.current_operation = "cancel"
            elif "view" in command.lower() or "show" in command.lower() or "list" in command.lower() or "all" in command.lower():
                st.session_state.current_operation = "view"
            elif "menu" in command.lower() or "home" in command.lower() or "main" in command.lower() or "back" in command.lower():
                st.session_state.current_operation = None
                st.session_state.booking_step = None
        else:
            placeholder.error("Sorry, I couldn't recognize your command. Please try again.")
        
        st.session_state.listening = False
        st.rerun()

# Display voice command status
if st.session_state.voice_message:
    st.info(st.session_state.voice_message)

# Voice command help
with st.expander("Voice Command Help"):
    st.write("""
    ## How to Use Voice Commands
    
    ### Main Operations:
    - Say **"Book a ticket"** or **"New ticket"** - To create a new booking
    - Say **"Modify a ticket"** or **"Edit ticket"** - To change an existing ticket
    - Say **"Cancel a ticket"** or **"Delete ticket"** - To remove a ticket
    - Say **"View tickets"** or **"Show all tickets"** - To see all bookings
    - Say **"Main menu"** or **"Go back"** - To return to the main screen
    
    ### For booking, you can say everything at once:
    - **"Book a ticket for [name], age [age], from [source] to [destination]"**
    
    ### During the booking process:
    - When asked for your name, simply say your full name
    - When asked for age, say the number
    - When asked for gender, say "Male", "Female", or "Other"
    - When asked for stations, say the station name clearly
    
    ### For confirming:
    - Say **"Yes"** or **"Confirm"** to proceed
    - Say **"No"** or **"Cancel"** to abort
    """)

# Main operation selection
if st.session_state.current_operation is None:
    st.write("## Say a Command to Start")
    st.write("Say 'Book a ticket', 'Modify a ticket', 'Cancel a ticket', or 'View tickets'")
    
    # Show available commands visually
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.info("🎙️ Say: **Book a ticket**")
    
    with col2:
        st.info("🎙️ Say: **Modify a ticket**")
    
    with col3:
        st.info("🎙️ Say: **Cancel a ticket**")
    
    with col4:
        st.info("🎙️ Say: **View tickets**")

# Book Ticket Process
elif st.session_state.current_operation == "book":
    st.write("## Book a New Ticket")
    
    # Get station list for validation
    stations = get_station_list()
    
    if st.session_state.booking_step == "collect_details":
        # We need to collect ticket details via voice
        if 'name' not in st.session_state.ticket_details or not st.session_state.ticket_details['name']:
            st.write("### Please say your full name")
            if st.button("🎤 Speak Name", key="speak_name"):
                st.session_state.listening = True
                placeholder = st.empty()
                placeholder.info("Listening... Say your full name.")
                
                name_input = listen_for_command()
                if name_input:
                    placeholder.success(f"Name recorded: {name_input}")
                    st.session_state.ticket_details['name'] = name_input
                    time.sleep(1)
                    st.rerun()
                else:
                    placeholder.error("Could not recognize your name. Please try again.")
                st.session_state.listening = False
                
        elif 'age' not in st.session_state.ticket_details or not st.session_state.ticket_details.get('age'):
            st.write("### Please say your age")
            if st.button("🎤 Speak Age", key="speak_age"):
                st.session_state.listening = True
                placeholder = st.empty()
                placeholder.info("Listening... Say your age as a number.")
                
                age_input = listen_for_command()
                if age_input:
                    # Try to extract age as a number
                    try:
                        # First attempt to extract just the number if other words were spoken
                        age_match = re.search(r'\b(\d+)\b', age_input)
                        if age_match:
                            age = int(age_match.group(1))
                        else:
                            age = int(age_input)
                            
                        if 1 <= age <= 120:
                            placeholder.success(f"Age recorded: {age}")
                            st.session_state.ticket_details['age'] = age
                            time.sleep(1)
                            st.rerun()
                        else:
                            placeholder.error("Age must be between 1 and 120. Please try again.")
                    except ValueError:
                        placeholder.error("Could not understand age. Please say a number clearly.")
                else:
                    placeholder.error("Could not recognize your age. Please try again.")
                st.session_state.listening = False
        
        elif 'gender' not in st.session_state.ticket_details:
            st.write("### Please say your gender (Male, Female, or Other)")
            if st.button("🎤 Speak Gender", key="speak_gender"):
                st.session_state.listening = True
                placeholder = st.empty()
                placeholder.info("Listening... Say Male, Female, or Other.")
                
                gender_input = listen_for_command()
                if gender_input:
                    gender_input = gender_input.lower()
                    if "male" in gender_input:
                        st.session_state.ticket_details['gender'] = "Male"
                        placeholder.success("Gender recorded: Male")
                    elif "female" in gender_input:
                        st.session_state.ticket_details['gender'] = "Female"
                        placeholder.success("Gender recorded: Female")
                    else:
                        st.session_state.ticket_details['gender'] = "Other"
                        placeholder.success("Gender recorded: Other")
                    time.sleep(1)
                    st.rerun()
                else:
                    placeholder.error("Could not recognize your gender. Please try again.")
                st.session_state.listening = False
        
        elif 'source' not in st.session_state.ticket_details or not st.session_state.ticket_details['source']:
            st.write("### Please say your source station")
            st.write("Available stations:")
            st.write(", ".join(stations[:10]) + "... and more")
            
            if st.button("🎤 Speak Source Station", key="speak_source"):
                st.session_state.listening = True
                placeholder = st.empty()
                placeholder.info("Listening... Say your source station name.")
                
                source_input = listen_for_command()
                if source_input:
                    # Find closest matching station
                    best_match = None
                    best_score = 0
                    for station in stations:
                        # Simple matching algorithm - if the station name contains any part of the input
                        if source_input.lower() in station.lower() or station.lower() in source_input.lower():
                            # Calculate match score based on length of overlap
                            score = len(set(source_input.lower()) & set(station.lower()))
                            if score > best_score:
                                best_score = score
                                best_match = station
                    
                    if best_match:
                        placeholder.success(f"Source station recognized: {best_match}")
                        st.session_state.ticket_details['source'] = best_match
                        time.sleep(1)
                        st.rerun()
                    else:
                        placeholder.error("Could not match your station. Please try again with a valid station name.")
                else:
                    placeholder.error("Could not recognize the station. Please try again.")
                st.session_state.listening = False
        
        elif 'destination' not in st.session_state.ticket_details or not st.session_state.ticket_details['destination']:
            st.write("### Please say your destination station")
            st.write("Available stations:")
            st.write(", ".join(stations[:10]) + "... and more")
            
            if st.button("🎤 Speak Destination Station", key="speak_destination"):
                st.session_state.listening = True
                placeholder = st.empty()
                placeholder.info("Listening... Say your destination station name.")
                
                destination_input = listen_for_command()
                if destination_input:
                    # Find closest matching station
                    best_match = None
                    best_score = 0
                    for station in stations:
                        # Simple matching algorithm
                        if destination_input.lower() in station.lower() or station.lower() in destination_input.lower():
                            # Calculate match score based on length of overlap
                            score = len(set(destination_input.lower()) & set(station.lower()))
                            if score > best_score:
                                best_score = score
                                best_match = station
                    
                    if best_match:
                        if best_match == st.session_state.ticket_details.get('source'):
                            placeholder.error("Destination cannot be the same as source. Please choose a different station.")
                        else:
                            placeholder.success(f"Destination station recognized: {best_match}")
                            st.session_state.ticket_details['destination'] = best_match
                            time.sleep(1)
                            # Move to confirmation step
                            st.session_state.booking_step = "confirm"
                            st.rerun()
                    else:
                        placeholder.error("Could not match your station. Please try again with a valid station name.")
                else:
                    placeholder.error("Could not recognize the station. Please try again.")
                st.session_state.listening = False
        
    elif st.session_state.booking_step == "confirm":
        # Show collected details and confirm
        st.write("### Please confirm your ticket details:")
        st.write(f"**Name:** {st.session_state.ticket_details.get('name', 'Not provided')}")
        st.write(f"**Age:** {st.session_state.ticket_details.get('age', 'Not provided')}")
        st.write(f"**Gender:** {st.session_state.ticket_details.get('gender', 'Not provided')}")
        st.write(f"**From:** {st.session_state.ticket_details.get('source', 'Not provided')}")
        st.write(f"**To:** {st.session_state.ticket_details.get('destination', 'Not provided')}")
        
        st.write("### Is this information correct? Say 'Yes' to confirm or 'No' to cancel")
        
        if st.button("🎤 Speak Confirmation", key="speak_confirmation"):
            st.session_state.listening = True
            placeholder = st.empty()
            placeholder.info("Listening... Say 'Yes' to confirm or 'No' to cancel.")
            
            confirmation = listen_for_command()
            if confirmation:
                if "yes" in confirmation.lower() or "correct" in confirmation.lower() or "confirm" in confirmation.lower():
                    # Create the ticket
                    ticket = book_ticket(
                        st.session_state.ticket_details.get('name', ''),
                        st.session_state.ticket_details.get('age', 25),
                        st.session_state.ticket_details.get('gender', 'Other'),
                        st.session_state.ticket_details.get('source', ''),
                        st.session_state.ticket_details.get('destination', '')
                    )
                    st.session_state.tickets.append(ticket)
                    
                    placeholder.empty()
                    st.success("✅ SUCCESSFULLY TICKET IS BOOKED!")
                    st.write(f"Ticket ID: {ticket['id']}")
                    
                    # Reset the booking state
                    st.session_state.booking_step = None
                    st.session_state.ticket_details = {}
                    time.sleep(3)
                    st.session_state.current_operation = None
                    st.rerun()
                else:
                    placeholder.info("Booking cancelled. Returning to main menu.")
                    # Reset the booking state
                    st.session_state.booking_step = None
                    st.session_state.ticket_details = {}
                    time.sleep(2)
                    st.session_state.current_operation = None
                    st.rerun()
            else:
                placeholder.error("Could not recognize your response. Please try again.")
            st.session_state.listening = False
    
    # Button to abort booking and return to main menu
    if st.button("🔙 Return to Main Menu", key="book_back_button"):
        st.session_state.current_operation = None
        st.session_state.booking_step = None
        st.session_state.ticket_details = {}
        st.rerun()

# Modify Ticket
elif st.session_state.current_operation == "modify":
    st.write("## Modify Existing Ticket")
    
    if not st.session_state.tickets:
        st.warning("No tickets available to modify.")
    else:
        # Show ticket selection
        ticket_ids = [ticket['id'] for ticket in st.session_state.tickets]
        selected_id = st.selectbox("Select Ticket to Modify", options=ticket_ids)
        
        # Get the ticket with the selected ID
        ticket_to_modify = get_ticket_by_id(selected_id, st.session_state.tickets)
        
        if ticket_to_modify:
            st.write("### Current Ticket Details:")
            st.write(f"**Name:** {ticket_to_modify['name']}")
            st.write(f"**Age:** {ticket_to_modify['age']}")
            st.write(f"**Gender:** {ticket_to_modify['gender']}")
            st.write(f"**From:** {ticket_to_modify['source']}")
            st.write(f"**To:** {ticket_to_modify['destination']}")
            
            st.write("### Update Ticket Details:")
            with st.form(key="modify_ticket_form"):
                name = st.text_input("Full Name", value=ticket_to_modify['name'])
                
                col1, col2 = st.columns(2)
                with col1:
                    age = st.number_input("Age", min_value=1, max_value=120, value=ticket_to_modify['age'])
                with col2:
                    gender = st.selectbox("Gender", options=["Male", "Female", "Other"], 
                                        index=["Male", "Female", "Other"].index(ticket_to_modify['gender']))
                
                stations = get_station_list()
                source = st.selectbox("From (Source Station)", options=stations, 
                                     index=stations.index(ticket_to_modify['source']))
                destination = st.selectbox("To (Destination Station)", options=stations, 
                                          index=stations.index(ticket_to_modify['destination']))
                
                submit_button = st.form_submit_button(label="Update Ticket")
                
                if submit_button:
                    # Validation
                    if not name:
                        st.error("Please enter the name")
                    elif source == destination:
                        st.error("Source and destination stations cannot be the same")
                    else:
                        # Update the ticket
                        updated_ticket = modify_ticket(
                            selected_id, name, age, gender, source, destination, st.session_state.tickets
                        )
                        
                        if updated_ticket:
                            st.success("✅ Ticket updated successfully!")
                            time.sleep(2)
                            st.session_state.current_operation = None
                            st.rerun()
                        else:
                            st.error("Failed to update ticket. Please try again.")
    
    if st.button("Back to Main Menu"):
        st.session_state.current_operation = None
        st.rerun()

# Cancel Ticket
elif st.session_state.current_operation == "cancel":
    st.write("## Cancel Ticket")
    
    if not st.session_state.tickets:
        st.warning("No tickets available to cancel.")
    else:
        # Show ticket selection
        ticket_ids = [ticket['id'] for ticket in st.session_state.tickets]
        selected_id = st.selectbox("Select Ticket to Cancel", options=ticket_ids)
        
        # Get the ticket with the selected ID
        ticket_to_cancel = get_ticket_by_id(selected_id, st.session_state.tickets)
        
        if ticket_to_cancel:
            st.write("### Ticket Details:")
            st.write(f"**Name:** {ticket_to_cancel['name']}")
            st.write(f"**Age:** {ticket_to_cancel['age']}")
            st.write(f"**Gender:** {ticket_to_cancel['gender']}")
            st.write(f"**From:** {ticket_to_cancel['source']}")
            st.write(f"**To:** {ticket_to_cancel['destination']}")
            
            st.warning("Are you sure you want to cancel this ticket?")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Yes, Cancel Ticket"):
                    # Cancel the ticket
                    if cancel_ticket(selected_id, st.session_state.tickets):
                        st.success("Ticket cancelled successfully!")
                        time.sleep(2)
                        st.session_state.current_operation = None
                        st.rerun()
                    else:
                        st.error("Failed to cancel ticket. Please try again.")
            
            with col2:
                if st.button("No, Keep Ticket"):
                    st.session_state.current_operation = None
                    st.rerun()
    
    if st.button("Back to Main Menu"):
        st.session_state.current_operation = None
        st.rerun()

# View Tickets
elif st.session_state.current_operation == "view":
    st.write("## View All Tickets")
    
    tickets = get_all_tickets(st.session_state.tickets)
    
    if not tickets:
        st.info("No tickets booked yet.")
    else:
        # Create a DataFrame for better display
        tickets_df = pd.DataFrame(tickets)
        # Reorder columns
        if not tickets_df.empty:
            tickets_df = tickets_df[['id', 'name', 'age', 'gender', 'source', 'destination', 'booking_time']]
            # Convert booking_time to a more readable format
            tickets_df['booking_time'] = pd.to_datetime(tickets_df['booking_time']).dt.strftime('%Y-%m-%d %H:%M')
            
            st.dataframe(tickets_df, use_container_width=True)
            
            # Expand to see individual tickets
            with st.expander("View Individual Tickets"):
                for ticket in tickets:
                    st.write(f"**Ticket ID:** {ticket['id']}")
                    st.write(f"**Name:** {ticket['name']}")
                    st.write(f"**Age:** {ticket['age']}")
                    st.write(f"**Gender:** {ticket['gender']}")
                    st.write(f"**From:** {ticket['source']}")
                    st.write(f"**To:** {ticket['destination']}")
                    st.write(f"**Booking Time:** {ticket['booking_time']}")
                    st.divider()
    
    if st.button("Back to Main Menu"):
        st.session_state.current_operation = None
        st.rerun()

# Footer
st.markdown("---")
st.markdown("### Railway Ticket Reservation System")
st.markdown("Use the voice assistant or buttons to navigate and perform actions")
